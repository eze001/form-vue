<template>
    <div id="MiFormulario">
        <form action="" method="POST">
            <h1>Encuesta del Dojo</h1>
            <p>Tu Nombre: <input type="text" v-model="nombre"></p>
            <p>Localización del Dojo:
                <select v-model="localizacion">
                    <option value="1">Temuco</option>
                    <option value="2">Concepción</option>
                    <option value="3">Talca</option>
                    <option value="4">Rancagua</option>
                    <option value="5">Otro</option>
                </select>
            </p>
            <p>Lenguaje Favorito:
                <select v-model="lenguaje">
                    <option value="1">Javascript</option>
                    <option value="2">Python</option>
                    <option value="3">C++</option>
                    <option value="4">Scilab</option>
                    <option value="5">Otro</option>
                </select>
            </p>
            <p>Comentarios: <textarea v-model="desc"></textarea></p>
            <p><input type="submit" value="Enviar"></p>
        </form>
    </div>
</template>

<script>
    export default {
        name: "MiFormulario",
        data: function() {
            return {
                nombre: '',
                localizacion: 1,
                lenguaje: 2,
                desc: 'Descripción por defecto'
            };
        }
    }
</script>
